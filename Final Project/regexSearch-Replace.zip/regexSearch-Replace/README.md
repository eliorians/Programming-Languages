Contributors: Kyle Kennedy & Eli Orians

This project is implementing a RegEx Search and Replace program in haskell.

The program will take as input a filename, a string to search the file for, and a string to replace the matched string with.

We will also implement the feature ability to save a matched pattern as a variable, for later reference in the searching string, or replacing string.
